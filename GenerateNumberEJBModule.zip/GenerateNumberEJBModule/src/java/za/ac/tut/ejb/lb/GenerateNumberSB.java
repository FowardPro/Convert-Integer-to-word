/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.ejb.lb;

import java.util.Map;
import javax.ejb.Stateless;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Foward
 */
@Stateless
public class GenerateNumberSB implements GenerateNumberSBLocal {

    @Override
    public boolean isNumberValid(Integer number)  throws NumberException {
        boolean validate;
        if(number>=0 && number<=9)
        {
            validate= true;
        }
        else
        {
            validate = false;
        throw new NumberException("The number is invalid"); 
        }
        return validate;
        
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public String convertNumberToString(Integer number){
        String output="";
        if(isNumberValid(number))
        {
        switch (number) {
            case 0:output="Zero";break;
            case 1:output="One";break;
            case 2:output="Two";break;
            case 3:output="Thre";break;
            case 4:output="Four";break;
            case 5:output="Five";break;
            case 6:output="Six";break;
            case 7:output="Seven";break;
            case 8:output="Eight";break;
            case 9:output="Nine";break;
            default:
                break;
        }
        
    }
        return output;
    }

    @Override
    public void updateSession(Integer number, String output, HttpSession session) {
        
        //Set new Atributes
        session.setAttribute("output", output);
        session.setAttribute("number", number);
        //Update summary data
        Map<Integer,String> summaryData=(Map<Integer,String>)session.getAttribute("summaryData");
        summaryData.put(number, output);
        session.setAttribute("summaryData", summaryData);
        
        //Update attempts
        Integer attemps=(Integer)session.getAttribute("attemps");
        attemps++;
        session.setAttribute("attemps", attemps);
    }
    
}
