
package za.ac.tut.ejb.lb;

import javax.ejb.EJBException;

public class NumberException extends EJBException{

    public NumberException(String message) {
        super(message);
    }
    
}
