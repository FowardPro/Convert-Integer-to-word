/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Foward
 */
public class StartSessionServlet extends HttpServlet {

    
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session =request.getSession(true);
        intialiseSession(session);
        RequestDispatcher disp=request.getRequestDispatcher("enter_number.html");
        disp.forward(request, response);
    }

    private void intialiseSession(HttpSession session) {
        Map<Integer,String> summaryData=new HashMap<>();
        int attemps=0;
        session.setAttribute("summaryData", summaryData);
        session.setAttribute("attemps", attemps);
        
    }

}
